This folder contains some of the bugs found by redqueen.

The full list of CVEs uncovered by redqueen can be found below:

CVE-2018-12641 (binutils nm-new)
CVE-2018-12697 (binutils libiberty)
CVE-2018-12698 (binutils libiberty)
CVE-2018-12699 (binutils objdump)
CVE-2018-12700 (binutils objdump)
CVE-2018-12928 (Linux kernel 4.15.0 hfs.ko)
CVE-2018-12929 (Linux kernel 4.15.0 ntfs.ko)
CVE-2018-12930 (Linux kernel 4.15.0 ntfs.ko)
CVE-2018-12931 (Linux kernel 4.15.0 ntfs.ko)
CVE-2018-12932 (Wine)
CVE-2018-12933 (Wine)
CVE-2018-12934 (binutils cxxfilt)
CVE-2018-12935 (imagemagik)
CVE-2018-14337 (mruby)
CVE-2018-14566 (bash)
CVE-2018-14567 (xml2)
CVE-2018-16747 (fdk-aac)
CVE-2018-16748 (fdk-aac)
CVE-2018-16749 (ImageMagick)
CVE-2018-16750 (ImageMagick)
CVE-2018-20116 (tcpdump)
CVE-2018-20117 (tcpdump)
CVE-2018-20118 (tcpdump)
CVE-2018-20119 (tcpdump)

