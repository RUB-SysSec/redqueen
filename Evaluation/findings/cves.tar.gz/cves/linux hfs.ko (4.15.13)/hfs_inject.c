/*
gcc test.c -o hfs_fuzzer

Copyright (C) 2018 Sergej Schumilo

This file is part of kAFL Fuzzer (kAFL).

QEMU-PT is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

QEMU-PT is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with QEMU-PT.  If not, see <http://www.gnu.org/licenses/>.

*/

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdint.h>
#include <sys/mman.h>
#include <sys/ioctl.h>
#include <string.h>
#include <sys/mount.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <linux/loop.h>

#define KAFL_TMP_FILE	"/tmp/trash"

uint32_t read_file(uint8_t** buffer, char* filename){
	FILE    *infile;
	uint32_t  numbytes;

	infile = fopen(filename, "r");	
	if(infile == NULL)
		return 1;
	
	fseek(infile, 0L, SEEK_END);
	numbytes = ftell(infile);
	
	fseek(infile, 0L, SEEK_SET);	
	
	*buffer = (char*)calloc(numbytes, sizeof(char));	
	
	if(*buffer == NULL)
		return 1;
	
	fread(*buffer, sizeof(char), numbytes, infile);
	fclose(infile);
	return numbytes;
}

int main(int argc, char** argv)
{
	struct stat st = {0};
	int ret;
	char loopname[4096];
	int loopctlfd, loopfd, backingfile;
    long devnr;
    uint8_t* buffer; 
    uint32_t num_bytes;


	num_bytes = read_file(&buffer, argv[1]);

	system("mkdir /tmp/a/");
	loopctlfd = open("/dev/loop-control", O_RDWR);
	devnr = ioctl(loopctlfd, LOOP_CTL_GET_FREE);
	sprintf(loopname, "/dev/loop%ld", devnr);
	close(loopctlfd);

	loopfd = open(loopname, O_RDWR);
	backingfile = open(KAFL_TMP_FILE, O_RDWR | O_CREAT | O_SYNC, 0777);
	ioctl(loopfd, LOOP_SET_FD, backingfile);

	write(backingfile, buffer, 1024*64);

	ret = mount(loopname, "/tmp/a/", "hfs", 0x1, NULL);
	umount2("/tmp/a", MNT_FORCE);

	while(1){
		
		lseek(backingfile, 0, SEEK_SET);
		write(backingfile, buffer, num_bytes);
		fsync(backingfile);
		ioctl(loopfd, LOOP_SET_CAPACITY, 0);

		ret = mount(loopname, "/tmp/a/", "hfs", 0x1, NULL);

		mkdir("/tmp/a/trash", 0700);
		stat("/tmp/a/trash", &st);
    	umount2("/tmp/a", MNT_FORCE);
	}
	close(backingfile);
    return 0;
}

