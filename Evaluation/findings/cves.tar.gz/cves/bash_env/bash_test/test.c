#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>

char** to_env(char* data, size_t size) {
  size_t count = 0;
  for(size_t i = 0; i < size; i++){
    if(data[i] == 0)
      count ++;
  }
  char** res = (char**)calloc(sizeof(char*), count+1);
  if(!res){return NULL;}
  size_t env = 0;
  size_t last_index = 0;
  for(size_t i = 0; i< size; i++){
    if(data[i] == 0){
      res[env] = &data[last_index];
      env += 1;
      last_index = i+1;
    }
  }
  res[count] = NULL;
  return res;
}


int main(int argc, char** argv){

	FILE    *infile;
	char    *buffer;
	long    numbytes;

	if(argc <= 1){
		return -1;
	}

	infile = fopen(argv[1], "r");	
	if(infile == NULL)
		return 1;

	fseek(infile, 0L, SEEK_END);
	numbytes = ftell(infile);

	fseek(infile, 0L, SEEK_SET);	

	buffer = (char*)calloc(numbytes, sizeof(char));	

	if(buffer == NULL){
		printf("FAIL!\n");
		return 1;

	}

	fread(buffer, sizeof(char), numbytes, infile);
	fclose(infile);

	printf("YO\n");

	pid_t pid;
  char *const parmList[] = {NULL};
  char** envParms = to_env(buffer, numbytes);

	char *newenviron[] = { NULL };

  /*
  if ((pid = fork()) ==-1)
    perror("fork error");
  else if (pid == 0) {
	  int pipefd[2];
	  pipe(pipefd);
	  dup2(pipefd[0],STDIN_FILENO);
    write(pipefd[1], "uname\n", 6);
    close(pipefd[1]);
  */
    execve("bash", parmList, envParms);
    // execve("/home/sww13/fuzz/target/bash/git/bash-asan", parmList, envParms);
    printf("Return not expected. Must be an execve error.n");
  // }
}
