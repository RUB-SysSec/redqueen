require 'csv'
last_time = nil
first_time = nil
acc = nil
count = 0
CSV.open('converted.csv', 'wb') do |csv|
  CSV.foreach('data.csv',col_sep: ";") do |row|
    time,*data = *row
    time = time.to_i
    data = data.map(&:to_i)
    first_time = time unless first_time
    acc ||= data.map{0}
    acc.each_index{|i| acc[i]+=data[i]}
    count += 1
    if !last_time || time - last_time > 2
      csv << [time-first_time, *(acc.map{|v| v/count.to_f})]
      last_time = time
      acc = acc.map{0}
      count = 0
    end
  end
end
